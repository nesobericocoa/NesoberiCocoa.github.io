
const ABILITIES=[
 ["turf","芝"],["dirt","ダート"],["front","逃げ"],["pace","先行"],["stalker","差し"],["closer","追込"],
 ["temper","気性難対応"],["tactics","他馬対策"],["start","スタート"],["paceSense","ペース判断"],
 ["wet","道悪"],["staminaRide","長距離"],["sprintRide","短距離"],["pressure","勝負強さ"]
];
const STYLES=["逃げ","先行","差し","追込"];
const CLASS_ORDER=["未勝利","1勝クラス","2勝クラス","3勝クラス","オープン"];
const defaultState=()=>({
 version:2,gameDate:"2026-01-01",racecourses:[],horses:[],jockeys:[],races:[],gradeTemplates:[],
 trainingLog:[],nextIds:{horse:1,jockey:1,race:1,gradeTemplate:1}
});
let state=defaultState();
const $=id=>document.getElementById(id);
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const rnd=(a,b)=>Math.floor(Math.random()*(b-a+1))+a;
const chance=p=>Math.random()<p;
const fmt=d=>d.toISOString().slice(0,10);
const today=()=>new Date(state.gameDate+"T00:00:00");
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const yen=n=>new Intl.NumberFormat("ja-JP").format(n)+"万円";

async function dbOpen(){return await new Promise((res,rej)=>{const q=indexedDB.open("horseRacingMobileDB",1);q.onupgradeneeded=()=>q.result.createObjectStore("kv");q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)})}
async function saveLocal(){const db=await dbOpen();await new Promise((res,rej)=>{const tx=db.transaction("kv","readwrite");tx.objectStore("kv").put(state,"state");tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}
async function loadLocal(){const db=await dbOpen();const v=await new Promise((res,rej)=>{const tx=db.transaction("kv","readonly"),q=tx.objectStore("kv").get("state");q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)});if(v)state=upgradeState(v)}
function upgradeState(s){
 s.version=2;s.gradeTemplates=s.gradeTemplates||[];s.trainingLog=s.trainingLog||[];s.nextIds=s.nextIds||{horse:1,jockey:1,race:1,gradeTemplate:1};s.nextIds.gradeTemplate=s.nextIds.gradeTemplate||1;
 for(const h of s.horses||[]){
  h.weightBase=h.weightBase||rnd(430,540);h.weight=h.weight||h.weightBase;h.fatigue=h.fatigue??0;h.condition=h.condition??70;
  h.growthType=h.growthType||"普通";h.style=h.style||STYLES[rnd(0,3)];h.earnings=h.earnings||0;h.className=h.className||"未勝利";
  h.trainCount=h.trainCount||0;
 }
 return s;
}

function baseHorseAbility(){return{
 speed:rnd(38,94),stamina:rnd(36,94),power:rnd(34,94),guts:rnd(30,94),
 turf:rnd(1,10),dirt:rnd(1,10),temper:rnd(1,10),health:rnd(1,10),
 distanceMin:[1000,1200,1400,1600,1800][rnd(0,4)],
 distanceMax:[2000,2200,2400,2800,3200][rnd(0,4)]
}}
function makeHorse(name,sex,age,style,growthType,sireId=null,damId=null,ability=null){
 const wb=rnd(420,550);
 return {id:state.nextIds.horse++,name,sex,age:+age,style,growthType,sireId:sireId?+sireId:null,damId:damId?+damId:null,
  ability:ability||baseHorseAbility(),results:[],injuryDays:0,retiredFatal:false,weightBase:wb,weight:wb+rnd(-10,10),
  fatigue:rnd(0,15),condition:rnd(65,90),earnings:0,className:"未勝利",trainCount:0,createdAt:state.gameDate}
}
const getHorse=id=>state.horses.find(h=>h.id===+id);
const getJockey=id=>state.jockeys.find(j=>j.id===+id);
const hname=id=>getHorse(id)?.name||"-";
function status(h){if(h.retiredFatal)return"予後不良";if(h.injuryDays>0)return`故障中 ${h.injuryDays}日`;return"出走可"}
function growthMultiplier(h){
 const peaks={早熟:3,普通:4,晩成:5},p=peaks[h.growthType]||4,d=Math.abs(h.age-p);
 if(h.age<p)return 0.88+Math.max(0,(h.age-2))*0.06;
 return Math.max(.78,1.04-d*.055)
}
function classFrom(h){
 const wins=h.results.filter(r=>r.position===1&&!r.grade).length;
 if(h.earnings>=8000||h.results.some(r=>r.grade==="G1"&&r.position<=3))return"オープン";
 return CLASS_ORDER[Math.min(3,wins)]||"未勝利"
}

function jockeyCompat(h,j){
 if(!j)return 1;
 let x=(h.id*1103515245+j.id*12345)&0x7fffffff;
 return 1+(x%10);
}
function styleKey(style){return ({逃げ:"front",先行:"pace",差し:"stalker",追込:"closer"})[style]}
function goingBonus(j,going){if(!j)return 0;return ["重","不良"].includes(going)?(j.a.wet-5)*1.2:0}
function ageAndGrowthText(h){return `${h.age}歳 / ${h.growthType} / 成長${Math.round(growthMultiplier(h)*100)}%`}

function renderAll(){
 $("gameDate").textContent=state.gameDate;
 $("horseCount").textContent=state.horses.length;$("jockeyCount").textContent=state.jockeys.length;
 $("totalEarnings").textContent=yen(state.horses.reduce((a,h)=>a+h.earnings,0));
 const future=state.races.filter(r=>!r.run&&r.date>=state.gameDate).sort((a,b)=>a.date.localeCompare(b.date))[0];
 $("nextRaceLabel").textContent=future?`${future.date} ${future.name}`:"次走なし";
 renderInjury();renderHorses();renderJockeys();renderRacecourses();renderRaces();renderTrain();renderBreeding();renderPedigree();renderRankings();renderGradeTemplates();
}
function renderInjury(){
 const list=state.horses.filter(h=>h.injuryDays>0||h.retiredFatal).slice(0,8);
 $("injurySummary").innerHTML=list.length?list.map(h=>`<div class="logItem"><b>${esc(h.name)}</b> — ${status(h)}</div>`).join(""):`<div class="hint">該当馬なし</div>`;
}
function renderHorses(){
 const q=$("horseSearch").value?.toLowerCase()||"";
 const list=state.horses.filter(h=>h.name.toLowerCase().includes(q));
 $("horseCards").innerHTML=list.map(h=>{
  const wins=h.results.filter(r=>r.position===1).length,cl=h.retiredFatal?"statusDead":h.injuryDays?"statusBad":"";
  return `<div class="horseCard" data-horse="${h.id}">
   <div class="cardHead"><div><h3>${esc(h.name)}</h3><div class="sub">${h.sex}${h.age} / ${h.style} / ${h.growthType}</div></div><span class="badge ${cl}">${status(h)}</span></div>
   <div class="stats">
    <div class="stat">クラス<b>${h.className}</b></div><div class="stat">戦績<b>${h.results.length}戦${wins}勝</b></div><div class="stat">賞金<b>${yen(h.earnings)}</b></div>
    <div class="stat">馬体重<b>${h.weight}kg</b></div><div class="stat">疲労<b>${h.fatigue}%</b></div><div class="stat">調子<b>${h.condition}%</b></div>
   </div>
  </div>`
 }).join("")||`<div class="hint">登録馬がいません。</div>`;
 document.querySelectorAll("[data-horse]").forEach(el=>el.onclick=()=>showHorse(+el.dataset.horse))
}
function showHorse(id){
 const h=getHorse(id),a=h.ability;if(!h)return;
 const hist=[...h.results].reverse().slice(0,30).map(r=>`<div class="resultRow"><div class="place">${r.position??"-"}</div><div><b>${esc(r.race)}</b><div class="sub">${r.date} ${r.surface}${r.distance}m ${r.going||""}</div></div><div class="sub">${esc(r.note||"")}</div></div>`).join("");
 $("detailContent").innerHTML=`<h2>${esc(h.name)}</h2><p>${h.sex} / ${ageAndGrowthText(h)} / ${h.style}</p>
 <div class="stats">
  <div class="stat">速度<b>${a.speed}</b></div><div class="stat">持久<b>${a.stamina}</b></div><div class="stat">力<b>${a.power}</b></div>
  <div class="stat">根性<b>${a.guts}</b></div><div class="stat">芝<b>${a.turf}/10</b></div><div class="stat">ダート<b>${a.dirt}/10</b></div>
  <div class="stat">気性<b>${a.temper}/10</b></div><div class="stat">健康<b>${a.health}/10</b></div><div class="stat">適距離<b>${a.distanceMin}-${a.distanceMax}</b></div>
 </div>
 <p>父: ${esc(hname(h.sireId))}<br>母: ${esc(hname(h.damId))}</p>
 <p>馬体重 ${h.weight}kg / 疲労 ${h.fatigue}% / 調子 ${h.condition}% / 賞金 ${yen(h.earnings)}</p>
 <h3>成績</h3>${hist||'<p class="hint">未出走</p>'}`;
 $("detailDialog").showModal()
}
function renderJockeys(){
 $("jockeyCards").innerHTML=state.jockeys.map(j=>`<div class="jockeyCard">
  <div class="jockeyTop">${j.image?`<img class="avatar" src="${j.image}">`:`<div class="avatar"></div>`}<div><b>${esc(j.name)}</b><div class="sub">芝${j.a.turf} ダ${j.a.dirt} / 気性${j.a.temper} / 対策${j.a.tactics}</div></div></div>
  <div class="stats"><div class="stat">逃げ<b>${j.a.front}</b></div><div class="stat">先行<b>${j.a.pace}</b></div><div class="stat">差し<b>${j.a.stalker}</b></div><div class="stat">追込<b>${j.a.closer}</b></div><div class="stat">ペース<b>${j.a.paceSense}</b></div><div class="stat">勝負強さ<b>${j.a.pressure}</b></div></div>
 </div>`).join("")||`<div class="hint">騎手がいません。</div>`
}
function renderRacecourses(){
 $("racecourseList").innerHTML=state.racecourses.map((r,i)=>`<span class="chip">${esc(r)} <button data-delrc="${i}" class="ghost">×</button></span>`).join("");
 const opts=state.racecourses.map(r=>`<option>${esc(r)}</option>`).join("");
 $("racecourseSelect").innerHTML=opts;$("gradedCourse").innerHTML=opts;
 document.querySelectorAll("[data-delrc]").forEach(b=>b.onclick=async()=>{state.racecourses.splice(+b.dataset.delrc,1);await saveLocal();renderAll()})
}
function renderGradeTemplates(){
 $("gradeTemplateList").innerHTML=state.gradeTemplates.map(t=>`<div class="logItem"><b>${esc(t.name)}</b> ${t.grade} / ${t.month}月${t.day}日 / ${esc(t.course)} ${t.surface}${t.distance}m <button data-delgt="${t.id}" class="ghost">削除</button></div>`).join("")||`<div class="hint">まだありません。</div>`;
 document.querySelectorAll("[data-delgt]").forEach(b=>b.onclick=async()=>{state.gradeTemplates=state.gradeTemplates.filter(x=>x.id!==+b.dataset.delgt);await saveLocal();renderAll()})
}
function raceWeather(){
 const w=["晴","晴","曇","曇","小雨","雨"][rnd(0,5)];
 let g="良";if(w==="小雨")g=chance(.45)?"稍重":"良";if(w==="雨")g=chance(.5)?"重":"稍重";if(w==="雨"&&chance(.12))g="不良";
 return [w,g]
}
function prizeFor(r,pos){
 const base=r.grade==="G1"?15000:r.grade==="G2"?8000:r.grade==="G3"?5000:1200;
 return Math.round(base*([1,.4,.25,.15,.1][pos-1]||0))
}
function carriedWeight(h,r){
 let w=56;if(h.sex==="牝")w-=2;if(h.age<=3)w-=1;if(h.className==="オープン")w+=1;if(r.grade==="G1")w+=1;
 return w
}
function horseRaceScore(h,r,j,gate,going,carried){
 const a=h.ability,g=growthMultiplier(h),distPenalty=(r.distance<a.distanceMin||r.distance>a.distanceMax)?13:0;
 const surf=(r.surface==="芝"?a.turf:a.dirt)*3.0;
 const sk=styleKey(h.style),jStyle=j?j.a[sk]:5;
 const compat=j?jockeyCompat(h,j):5;
 const temperBonus=j?(j.a.temper-(11-a.temper))*1.1:0;
 const fatiguePenalty=h.fatigue*.12,conditionBonus=(h.condition-70)*.16,weightPenalty=Math.abs(h.weight-h.weightBase)*.08;
 const draw=(h.style==="逃げ"&&gate<=3)?2:(h.style==="追込"&&gate>=8)?1:0;
 const pace=j?((j.a.paceSense+j.a.tactics+j.a.pressure+jStyle+compat)/5):5;
 const handicap=(carried-56)*1.4;
 return (a.speed*.48+a.stamina*.23+a.power*.11+a.guts*.1)*g+surf+pace+temperBonus+goingBonus(j,going)+conditionBonus+draw-distPenalty-fatiguePenalty-weightPenalty-handicap+rnd(-9,9)
}
function renderRaces(){
 const list=[...state.races].sort((a,b)=>a.date.localeCompare(b.date)).slice(-160);
 $("raceCards").innerHTML=list.map(r=>`<div class="raceCard">
  <div class="cardHead"><div><h3>${r.grade?`[${r.grade}] `:""}${esc(r.name)}</h3><div class="sub">${r.date} / ${esc(r.course)}</div></div><span class="badge">${r.run?"確定":"未実施"}</span></div>
  <div class="raceMeta"><span class="chip">${r.surface}${r.distance}m</span>${r.weather?`<span class="chip">${r.weather}</span><span class="chip">${r.going}</span>`:""}</div>
  <button data-race="${r.id}">${r.run?"結果を見る":"レース実行"}</button>
 </div>`).join("")||`<div class="hint">番組がありません。</div>`;
 document.querySelectorAll("[data-race]").forEach(b=>b.onclick=()=>{const r=state.races.find(x=>x.id===+b.dataset.race);r.run?showRace(r.id):runRace(r.id)})
}
async function runRace(id){
 const r=state.races.find(x=>x.id===id);if(!r||r.run)return;
 let eligible=state.horses.filter(h=>!h.retiredFatal&&h.injuryDays<=0&&h.age>=2&&h.fatigue<92);
 if(eligible.length<2)return alert("出走可能な馬が2頭以上必要です");
 eligible=[...eligible].sort(()=>Math.random()-.5).slice(0,Math.min(12,eligible.length));
 const js=[...state.jockeys].sort(()=>Math.random()-.5),[weather,going]=raceWeather();r.weather=weather;r.going=going;
 const gates=Array.from({length:eligible.length},(_,i)=>i+1).sort(()=>Math.random()-.5),res=[];
 for(let i=0;i<eligible.length;i++){
  const h=eligible[i],j=js.length?js[i%js.length]:null,gate=gates[i],cw=carriedWeight(h,r);let note="",excluded=false,stopped=false;
  if(chance(.012)){excluded=true;note="競走除外"}
  if(!excluded&&chance(.017)){stopped=true;note="競走中止"}
  const injuryRisk=.006+(h.fatigue/100)*.025+Math.max(0,6-h.ability.health)*.002;
  if(!excluded&&chance(injuryRisk)){
   if(chance(.035)){h.retiredFatal=true;note+=(note?" / ":"")+"故障・予後不良"}
   else{h.injuryDays=rnd(7,120);note+=(note?" / ":"")+`故障・全治${h.injuryDays}日`}
  }
  res.push({horseId:h.id,jockeyId:j?.id||null,gate,carried:cw,compat:j?jockeyCompat(h,j):null,score:(excluded||stopped)?-999:horseRaceScore(h,r,j,gate,going,cw),note})
 }
 const fin=res.filter(x=>x.score>-900).sort((a,b)=>b.score-a.score);fin.forEach((x,i)=>x.position=i+1);res.filter(x=>x.score<=-900).forEach(x=>x.position=null);
 r.results=[...fin,...res.filter(x=>x.score<=-900)];r.run=true;
 for(const x of r.results){
  const h=getHorse(x.horseId),pr=prizeFor(r,x.position||99);h.earnings+=pr;h.fatigue=clamp(h.fatigue+rnd(18,32),0,100);h.condition=clamp(h.condition+rnd(-8,4),20,100);h.weight+=rnd(-8,3);
  h.results.push({date:r.date,race:r.name,grade:r.grade||null,surface:r.surface,distance:r.distance,going,weather,position:x.position,gate:x.gate,carried:x.carried,jockeyId:x.jockeyId,prize:pr,note:x.note});
  h.className=classFrom(h)
 }
 await saveLocal();renderAll();showRace(id)
}
function showRace(id){
 const r=state.races.find(x=>x.id===id);if(!r)return;
 $("detailContent").innerHTML=`<h2>${r.grade?`[${r.grade}] `:""}${esc(r.name)}</h2><p>${r.date} ${esc(r.course)} / ${r.surface}${r.distance}m / ${r.weather||"-"} ${r.going||""}</p>
 ${(r.results||[]).map(x=>{const h=getHorse(x.horseId),j=getJockey(x.jockeyId);return `<div class="resultRow"><div class="place">${x.position??"-"}</div><div><b>${x.gate}枠 ${esc(h?.name||"-")}</b><div class="sub">${esc(j?.name||"騎手なし")} / ${x.carried}kg / 相性${x.compat??"-"}</div></div><div class="sub">${esc(x.note||"")}</div></div>`}).join("")}`;
 $("detailDialog").showModal()
}

function renderTrain(){
 const opts=state.horses.filter(h=>!h.retiredFatal).map(h=>`<option value="${h.id}">${esc(h.name)}（疲労${h.fatigue}%）</option>`).join("");
 $("trainHorse").innerHTML=opts;
 $("trainingLog").innerHTML=[...state.trainingLog].reverse().slice(0,40).map(x=>`<div class="logItem">${x.date} <b>${esc(x.horse)}</b> — ${esc(x.text)}</div>`).join("")||`<div class="hint">まだありません。</div>`
}
async function train(){
 const h=getHorse($("trainHorse").value);if(!h)return alert("馬を選択してね");if(h.injuryDays>0)return alert("故障中は調教できません");
 const type=$("trainType").value;
 if(type==="rest"){h.fatigue=clamp(h.fatigue-rnd(18,30),0,100);h.condition=clamp(h.condition+rnd(3,9),0,100);h.weight+=rnd(1,5);state.trainingLog.push({date:state.gameDate,horse:h.name,text:"休養して疲労を回復"});}
 else{
  const gain=chance(.35)?2:1;h.ability[type]=clamp(h.ability[type]+gain,1,99);h.fatigue=clamp(h.fatigue+rnd(8,18),0,100);h.condition=clamp(h.condition+rnd(-3,4),0,100);h.weight+=rnd(-4,1);h.trainCount++;
  const names={speed:"坂路",stamina:"長め",power:"ウッド",guts:"併せ馬"};let txt=`${names[type]}調教：${type} +${gain}`;
  const risk=.002+(h.fatigue/100)*.018+Math.max(0,5-h.ability.health)*.002;
  if(chance(risk)){h.injuryDays=rnd(5,45);txt+=` / 調教中に故障（${h.injuryDays}日）`}
  state.trainingLog.push({date:state.gameDate,horse:h.name,text:txt})
 }
 await saveLocal();renderAll()
}

function renderBreeding(){
 $("breedSire").innerHTML=state.horses.filter(h=>h.sex==="牡"&&!h.retiredFatal).map(h=>`<option value="${h.id}">${esc(h.name)}</option>`).join("");
 $("breedDam").innerHTML=state.horses.filter(h=>h.sex==="牝"&&!h.retiredFatal).map(h=>`<option value="${h.id}">${esc(h.name)}</option>`).join("")
}
function inheritedAbility(s,d){
 const sa=s.ability,da=d.ability,avg=(k,a,b)=>clamp(Math.round((sa[k]+da[k])/2+rnd(-11,11)),a,b);
 return{speed:avg("speed",20,99),stamina:avg("stamina",20,99),power:avg("power",20,99),guts:avg("guts",20,99),
 turf:avg("turf",1,10),dirt:avg("dirt",1,10),temper:avg("temper",1,10),health:avg("health",1,10),
 distanceMin:clamp(Math.round(((sa.distanceMin+da.distanceMin)/2+rnd(-200,200))/100)*100,800,2400),
 distanceMax:clamp(Math.round(((sa.distanceMax+da.distanceMax)/2+rnd(-200,300))/100)*100,1600,4000)}
}
function ancestors(id,depth=5,level=0,map=new Map()){
 const h=getHorse(id);if(!h||level>=depth)return map;
 for(const pid of [h.sireId,h.damId])if(pid){const key=+pid;if(!map.has(key))map.set(key,[]);map.get(key).push(level+1);ancestors(key,depth,level+1,map)}
 return map
}
function inbreedingInfo(sireId,damId){
 const a=ancestors(sireId,5),b=ancestors(damId,5),common=[];let coeff=0;
 for(const [id,ls] of a)if(b.has(id))for(const l1 of ls)for(const l2 of b.get(id)){const c=Math.pow(.5,l1+l2+1);coeff+=c;common.push({id,l1,l2,c})}
 common.sort((x,y)=>y.c-x.c);
 return{coeff:coeff*100,common}
}
function previewCross(){
 const s=getHorse($("breedSire").value),d=getHorse($("breedDam").value);if(!s||!d)return;
 const ib=inbreedingInfo(s.id,d.id),names=[...new Set(ib.common.map(x=>hname(x.id)))].slice(0,8);
 $("crossPreview").innerHTML=`<div class="logItem"><b>推定インブリード係数: ${ib.coeff.toFixed(2)}%</b><br>${names.length?`共通祖先: ${names.map(esc).join("、")}`:"5代以内の共通祖先なし"}</div>`
}
async function breed(){
 const s=getHorse($("breedSire").value),d=getHorse($("breedDam").value),name=$("foalName").value.trim();if(!s||!d||!name)return alert("父・母・産駒名を指定してね");
 const g=["早熟","普通","普通","晩成"][rnd(0,3)],foal=makeHorse(name,$("foalSex").value,0,$("foalStyle").value,g,s.id,d.id,inheritedAbility(s,d));
 state.horses.push(foal);$("foalName").value="";await saveLocal();renderAll();alert(`${name} が誕生しました`)
}

function renderPedigree(){
 $("pedigreeHorse").innerHTML=state.horses.map(h=>`<option value="${h.id}">${esc(h.name)}</option>`).join("");
 const id=+$("pedigreeHorse").value||state.horses[0]?.id;if(!id){$("pedigreeView").innerHTML='<p class="hint">馬を登録してください。</p>';return}
 $("pedigreeHorse").value=id;$("pedigreeView").innerHTML=pedigreeHTML(id)
}
function pedigreeHTML(id){
 const cols=Array.from({length:5},()=>[]);
 function walk(hid,level,path){
  if(level>=5)return;
  const h=getHorse(hid);const parents=h?[h.sireId,h.damId]:[null,null];
  for(const pid of parents){cols[level].push(pid?`<div class="pedNode">${esc(hname(pid))}</div>`:`<div class="pedNode founder">不明</div>`);walk(pid,level+1,path)}
 }
 walk(id,0,[]);
 const max=Math.max(...cols.map(c=>c.length),1);
 return `<div class="pedigreeTree">${cols.map(c=>`<div>${c.join("")}</div>`).join("")}</div>`
}

function renderRankings(){
 const sireMap=new Map();
 for(const h of state.horses)if(h.sireId){const s=getHorse(h.sireId);if(s){if(!sireMap.has(s.id))sireMap.set(s.id,{name:s.name,earn:0,wins:0,foals:0});const x=sireMap.get(s.id);x.earn+=h.earnings;x.wins+=h.results.filter(r=>r.position===1).length;x.foals++}}
 const sires=[...sireMap.values()].sort((a,b)=>b.earn-a.earn).slice(0,30);
 $("sireRanking").innerHTML=sires.map((x,i)=>`<div class="rankCard"><b>${i+1}. ${esc(x.name)}</b><div class="sub">産駒${x.foals}頭 / 勝利${x.wins} / 産駒賞金 ${yen(x.earn)}</div></div>`).join("")||`<div class="hint">産駒データがありません。</div>`;
 const hs=[...state.horses].sort((a,b)=>b.earnings-a.earnings).slice(0,30);
 $("horseRanking").innerHTML=hs.map((h,i)=>`<div class="rankCard"><b>${i+1}. ${esc(h.name)}</b><div class="sub">${h.className} / ${yen(h.earnings)} / ${h.results.length}戦${h.results.filter(r=>r.position===1).length}勝</div></div>`).join("")
}

function genNormalProgram(){
 const c=$("racecourseSelect").value;if(!c)return alert("競馬場を登録してね");let d=today(),n=1,dist=[1000,1200,1400,1600,1800,2000,2200,2400,2600,3000];
 for(let i=0;i<30;i++){const x=new Date(d);x.setDate(x.getDate()+i);if([0,6].includes(x.getDay()))for(let k=1;k<=8;k++)state.races.push({id:state.nextIds.race++,date:fmt(x),course:c,name:`第${n++}競走`,surface:chance(.58)?"芝":"ダート",distance:dist[rnd(0,dist.length-1)],grade:null,run:false,results:[]})}
}
function genYearGrades(){
 const y=today().getFullYear();let added=0;
 for(const t of state.gradeTemplates){const mm=String(t.month).padStart(2,"0"),dd=String(t.day).padStart(2,"0"),date=`${y}-${mm}-${dd}`;if(state.races.some(r=>r.date===date&&r.name===t.name))continue;
  state.races.push({id:state.nextIds.race++,date,course:t.course,name:t.name,surface:t.surface,distance:t.distance,grade:t.grade,run:false,results:[]});added++}
 alert(`${y}年の重賞を${added}件追加しました`)
}
async function advance(days){
 for(let i=0;i<days;i++){
  const old=today(),d=new Date(old);d.setDate(d.getDate()+1);
  const newYear=d.getFullYear()>old.getFullYear();state.gameDate=fmt(d);
  for(const h of state.horses){
   if(h.injuryDays>0)h.injuryDays--;h.fatigue=clamp(h.fatigue-rnd(2,5),0,100);h.condition=clamp(h.condition+rnd(-1,2),20,100);
   if(h.weight<h.weightBase)h.weight+=chance(.65)?1:0;else if(h.weight>h.weightBase)h.weight-=chance(.55)?1:0;
   if(newYear)h.age++;
  }
 }
 await saveLocal();renderAll()
}
async function fileToDataURL(f){if(!f)return"";return await new Promise(res=>{const fr=new FileReader();fr.onload=()=>res(fr.result);fr.readAsDataURL(f)})}

function go(tab){
 document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));$("tab-"+tab)?.classList.add("active");
 document.querySelectorAll(".bottomNav button").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));
 window.scrollTo({top:0,behavior:"smooth"});renderAll()
}

document.addEventListener("DOMContentLoaded",async()=>{
 ABILITIES.forEach(([k,l])=>$("abilityInputs").insertAdjacentHTML("beforeend",`<label>${l}<input id="ab_${k}" type="number" min="1" max="10" value="5"></label>`));
 await loadLocal();renderAll();

 document.querySelectorAll(".bottomNav button").forEach(b=>b.onclick=()=>{if(b.dataset.tab==="more")$("moreSheet").classList.remove("hidden");else go(b.dataset.tab)});
 document.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>{$("moreSheet").classList.add("hidden");go(b.dataset.go)});
 $("closeMore").onclick=()=>$("moreSheet").classList.add("hidden");$("moreSheet").onclick=e=>{if(e.target===$("moreSheet"))$("moreSheet").classList.add("hidden")};
 $("closeDialog").onclick=()=>$("detailDialog").close();

 $("toggleHorseForm").onclick=()=>$("horseForm").classList.toggle("hidden");
 $("toggleJockeyForm").onclick=()=>$("jockeyForm").classList.toggle("hidden");
 $("toggleGradeForm").onclick=()=>$("gradeForm").classList.toggle("hidden");

 $("addHorseBtn").onclick=async()=>{
  const name=$("horseName").value.trim();if(!name)return alert("馬名を入力してね");
  state.horses.push(makeHorse(name,$("horseSex").value,$("horseAge").value,$("horseStyle").value,$("horseGrowth").value,$("horseSire").value,$("horseDam").value));
  $("horseName").value="";await saveLocal();renderAll()
 };
 $("horseSearch").oninput=renderHorses;

 $("addJockeyBtn").onclick=async()=>{
  const name=$("jockeyName").value.trim();if(!name)return alert("騎手名を入力してね");if(state.jockeys.length>=50&&!confirm("騎手が50人を超えます。続けますか？"))return;
  const a={};ABILITIES.forEach(([k])=>a[k]=clamp(+$("ab_"+k).value||1,1,10));
  state.jockeys.push({id:state.nextIds.jockey++,name,a,image:await fileToDataURL($("jockeyImage").files[0])});
  $("jockeyName").value="";$("jockeyImage").value="";await saveLocal();renderAll()
 };

 $("addRacecourseBtn").onclick=async()=>{const n=$("racecourseName").value.trim();if(n&&!state.racecourses.includes(n))state.racecourses.push(n);$("racecourseName").value="";await saveLocal();renderAll()};
 $("generateProgramBtn").onclick=async()=>{genNormalProgram();await saveLocal();renderAll()};
 $("saveGradeTemplateBtn").onclick=async()=>{
  const n=$("gradedName").value.trim(),c=$("gradedCourse").value;if(!n||!c)return alert("重賞名と競馬場を入力してね");
  state.gradeTemplates.push({id:state.nextIds.gradeTemplate++,name:n,grade:$("gradedGrade").value,course:c,month:+$("gradedMonth").value,day:+$("gradedDay").value,surface:$("gradedSurface").value,distance:+$("gradedDistance").value});
  $("gradedName").value="";await saveLocal();renderAll()
 };
 $("generateYearGradesBtn").onclick=async()=>{genYearGrades();await saveLocal();renderAll()};

 $("trainBtn").onclick=train;$("previewCrossBtn").onclick=previewCross;$("breedBtn").onclick=breed;$("pedigreeHorse").onchange=renderPedigree;
 $("nextDayBtn").onclick=()=>advance(1);$("nextWeekBtn").onclick=()=>advance(7);

 $("exportBtn").onclick=()=>{const b=new Blob([JSON.stringify(state,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=`keiba-mobile-${state.gameDate}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)};
 $("importFile").onchange=async e=>{const f=e.target.files[0];if(!f)return;try{state=upgradeState(JSON.parse(await f.text()));await saveLocal();renderAll();alert("読み込み完了")}catch{alert("読み込みに失敗しました")}};
 $("resetBtn").onclick=async()=>{if(confirm("本当に全データを削除しますか？")){state=defaultState();await saveLocal();renderAll()}};
});
